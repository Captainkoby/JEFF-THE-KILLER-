/* eslint-disable sort-keys-fix/sort-keys-fix */
export default {
  Pioneer: 1,
  Infantry: 2,
  Artillery: 7,
  HeavyArtillery: 12,
  Medic: 26,
  Zombie: 47,
  Brute: 49,
  Cannon: 51,
  BazookaBear: 53,
  AIU: 54,
} as const;
/* eslint-enable sort-keys-fix/sort-keys-fix */
