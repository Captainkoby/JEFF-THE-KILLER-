import UnitPreviews from '@deities/hera/ui/demo/UnitPreviews.tsx';

export default function EntitiesExample() {
  return <UnitPreviews />;
}
