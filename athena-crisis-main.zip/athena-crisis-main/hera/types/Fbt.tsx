import type { fbt } from 'fbt';

export type Fbt = ReturnType<typeof fbt>;
