export const AnimationSpeed = {
  FastAI: 'FastAI',
  FastAll: 'FastAll',
  Normal: 'Normal',
} as const;
