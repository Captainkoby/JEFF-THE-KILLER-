export const ConfirmActionStyle = {
  Always: 'Always',
  Never: 'Never',
  Touch: 'Touch',
} as const;
