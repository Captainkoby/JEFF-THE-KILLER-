export const FogStyle = {
  Hard: 'Hard',
  Soft: 'Soft',
} as const;
