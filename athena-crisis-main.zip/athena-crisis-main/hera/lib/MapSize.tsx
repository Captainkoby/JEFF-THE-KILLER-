/* eslint-disable sort-keys-fix/sort-keys-fix */
export default {
  Micro: 'Micro',
  Small: 'Small',
  Medium: 'Medium',
  Large: 'Large',
} as const;
