export const TiltStyle = {
  Off: 'Off',
  On: 'On',
} as const;
